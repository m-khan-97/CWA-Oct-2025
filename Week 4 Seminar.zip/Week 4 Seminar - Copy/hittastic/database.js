import Database from 'better-sqlite3';
const db = new Database('./wadsongs.db'); // Ensure the db is in the right location
export default db;
