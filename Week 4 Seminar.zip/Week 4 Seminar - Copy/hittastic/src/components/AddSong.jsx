import { Form, Link, redirect } from "react-router-dom";

export default function AddSong(){
    return(
        <div>
            <h2>Add a Song</h2>
            <Form method="post">
                <input name="title" placeholder="Song Title" /><br />
                <input name="artist" placeholder="Artist" /><br />
                <input name="year" placeholder="Year" /><br />
                <button type="submit">Add Song</button>
            </Form>
            <br />
        </div>
    );
}

