import { useState } from "react";
import {Link, useNavigate} from "react-router-dom";

export default function App(){
    const [artist, setArtist] = useState("");
    const navigate = useNavigate();

    const handleSearch = (e) => {
        e.preventDefault();
        if(artist.trim() !==""){
            navigate(`/searchByArtist/${artist}`);
        }
    };

    return(
        <div>
            <h1>Welcome to Hittastic!</h1>
            <form onSubmit={handleSearch}>
                <input 
                type="text"
                placeholder="Enter Artist Name"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                />
                <button type="submit">Search</button>
            </form>
            <br />
            <Link to="/addsong">Add a Song</Link>
        </div>
    );

}