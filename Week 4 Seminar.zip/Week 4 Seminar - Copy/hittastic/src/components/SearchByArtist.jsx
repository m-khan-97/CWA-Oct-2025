import { useLoaderData, Link } from "react-router-dom";



export default function SearchByArtist(){
    

    return(
        <div>
            <h2>Results</h2>
            <ul>
                {results.map((song) => (
                    <li key={song.id}>
                        {song.title} by {song.artist} ({song.year})
                    </li>
                ))}
            </ul>

        </div>
    );
}