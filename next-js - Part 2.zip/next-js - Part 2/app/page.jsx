export default function Page() {
    return (
        <div>
            <h1>Welcome to Hittastic!</h1>
            <p>The best place to find your favourite songs</p>
        </div>
    );
}