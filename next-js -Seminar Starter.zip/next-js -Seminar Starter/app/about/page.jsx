export default function Page() {
    return (
        <div>
            <h2>About Hittastic</h2>
            <p>
                Hittastic! is a site for dsicovering timeless hits accross all genres - from rock and pop to jazz.
            </p>
        </div>
    );
}