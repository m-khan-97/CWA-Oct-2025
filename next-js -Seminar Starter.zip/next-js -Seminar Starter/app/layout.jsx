import './style.css';
import Link from 'next/link';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <div id="imgdiv">
          <img src="/hittastic.png" alt="HitTastic! logo" width="200" />
        </div>

        <nav>
          <Link href="/">Home</Link> | <Link href="/about">About</Link> |{' '}
          <Link href="/search?artist=Oasis">Search</Link>
        </nav>

        {children}
      </body>
    </html>
  );
}
