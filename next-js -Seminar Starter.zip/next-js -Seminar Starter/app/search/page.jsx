export default async function Page({ searchParams }) {
    const params = await searchParams
    return (
        <div>
            <h2>Searching for {params.artist}</h2>
            <p>You are searching for a song by {params.artist}</p>
        </div>
    );
}