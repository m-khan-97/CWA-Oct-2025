import React, { useState, useEffect }  from 'react';
import Search from './search.jsx';
import Login from './login.jsx';
import AddSong from './addsong.jsx';
import ModeChooser from './modechooser.jsx';
import ModeContext from '../contexts/ModeContext.js';
import useUserStatus from '../hooks/useUserStatus.js';

export default function App() {
   const [darkMode, setDarkMode] = useState(false);
   const [userInfo, setUserInfo] = useUserStatus();

    const { username, isadmin } = userInfo;

    const background = darkMode ? 'black' : 'white',
            foreground = darkMode ? 'white': 'black';
    return (
            <ModeContext.Provider value={{ darkMode, setDarkMode }}>
            <div style={{
                backgroundColor: background, 
                color: foreground, 
                padding: '10px',
                border: isadmin ? '5px solid red': ''
            }}>
            <Login onLoginStatusChange={handleLoginStatusChange} user={username} admin={isadmin} darkMode={darkMode} />
            <Search darkMode={darkMode} user={username} />
            <br />
            <ModeChooser darkMode={darkMode} modeUpdated={changeMode} />
            { isadmin ? <AddSong /> : "" }
            </div>;
            </ModeContext.Provider>
            );


    function handleLoginStatusChange(user, admin) {
        setUserInfo({ username: user, isadmin: admin });
    }

    function changeMode(mode) {
        setDarkMode(mode=='dark');
    }
}
