import { createContext } from 'react';

// This context will store our darkMode setting.
const ModeContext = createContext({
  darkMode: false,
  setDarkMode: () => {}
});

export default ModeContext;
