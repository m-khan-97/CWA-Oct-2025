import { useState, useEffect } from 'react';

export default function useUserStatus() {
  const [userInfo, setUserInfo] = useState({ username: null, isadmin: false });

  useEffect(() => {
    // Runs when app loads: ask server who's logged in
    fetch('/login')
      .then(res => res.json())
      .then(data => {
        if (data.username) {
          setUserInfo({ username: data.username, isadmin: data.isadmin });
        }
      })
      .catch(err => console.error('Error fetching login status:', err));
  }, []);

  // return both value and setter (just like useState)
  return [userInfo, setUserInfo];
}
